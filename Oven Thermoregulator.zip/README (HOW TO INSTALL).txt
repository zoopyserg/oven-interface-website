﻿Step 1: Run Setup.exe (not Setup.msi) - it will install the program alongside with .Net framework and MS SQL LocalDB database.
Step 2: Run GrantAccessToFiles.bat AS ADMINISTRATOR (it will make the database editable for the user, this step will be fixed in the future)
Step 3: Download and install the latest Microsoft SQL Server Management System (from this URL https://aka.ms/ssmsfullsetup ) - it is required on some systems to make the MSSQL database work properly.
Step 4: Reboot
Step 5: Run the program (Oven Thermoregulator.exe in your Start menu)

Your welcome!